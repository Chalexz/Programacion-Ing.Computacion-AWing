salas = []
sala_id_counter = 1

